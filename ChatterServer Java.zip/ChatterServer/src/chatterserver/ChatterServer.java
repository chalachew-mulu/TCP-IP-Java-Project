import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.Scanner;
import javax.swing.*;
public class ChatterServer extends JFrame{
public ChatterServer(){
setTitle("Server Chatter");
setSize(500,400);
setLayout(null);
setDefaultCloseOperation(3);
JScrollPane sp=new JScrollPane(txtBox);
sp.setBounds(10,10, 420, 200);
add(sp);
txtInput.setBounds(10, 250, 300, 30);
add(txtInput);
btnSend.setBounds(330, 250, 100, 30);
add(btnSend);
}
JTextArea txtBox=new JTextArea();
JButton btnSend=new JButton("SEND");
JTextField txtInput=new JTextField();

public static void main(String[] args)throws IOException{
final ChatterServer cs=new ChatterServer();
cs.setVisible(true);
ServerSocket ss=new ServerSocket(1313);
Socket sock=ss.accept();
final PrintWriter write=new PrintWriter(sock.getOutputStream());
final Scanner scan=new Scanner(sock.getInputStream());
cs.btnSend.addActionListener(new ActionListener(){
@Override
public void actionPerformed(ActionEvent ae){
write.println(cs.txtInput.getText());
cs.txtBox.append("\n"+"SERVER:"+cs.txtInput.getText());
cs.txtInput.setText("");
write.flush();
}
});
String clientMsg="";
while(true){
clientMsg=scan.nextLine();
cs.txtBox.append( "\n"+"CLIENT: "+clientMsg);
}
}}

