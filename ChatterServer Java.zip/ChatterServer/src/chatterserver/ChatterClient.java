import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.Scanner;
import javax.swing.*;
public class ChatterClient extends JFrame{
public ChatterClient(){
setTitle("Client Chatter");
setSize(500,400);
setLayout(null);
setDefaultCloseOperation(3);
JScrollPane sp=new JScrollPane(txtBox);
sp.setBounds(10,10, 420, 200);
add(sp);
txtInput.setBounds(10, 250, 300, 30);
add(txtInput);
btnSend.setBounds(330, 250, 100, 30);
add(btnSend);
}
JTextArea txtBox=new JTextArea();
JButton btnSend=new JButton("SEND");
JTextField txtInput=new JTextField();
PrintWriter write=null;
Scanner scan=null;
public static void main(String[] args)throws IOException{
final ChatterClient cs=new ChatterClient();
cs.setVisible(true);
Socket sock=new Socket("localhost",1313);
cs.write=new PrintWriter(sock.getOutputStream());
cs.scan=new Scanner(sock.getInputStream());
cs.btnSend.addActionListener(new ActionListener(){
@Override
public void actionPerformed(ActionEvent ae){
cs.write.println(cs.txtInput.getText());
cs.txtBox.append("\n"+"CLIENT: "+cs.txtInput.getText());
cs.txtInput.setText("");
cs.write.flush();
}    
});
String serverMsg="";
while(true){
serverMsg=cs.scan.nextLine();
cs.txtBox.append("\n"+"SERVER:"+serverMsg);
}}}